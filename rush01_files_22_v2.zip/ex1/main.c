/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: student <student@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/* ************************************************************************** */

#include <unistd.h>
#include <fcntl.h>
#include <libgen.h>

void	cat_fd(int fd);
void	print_error(char *file);

int	main(int argc, char **argv)
{
	int	i;
	int	fd;

	if (argc == 1)
		cat_fd(0);
	i = 1;
	while (i < argc)
	{
		fd = open(argv[i], O_RDONLY);
		if (fd < 0)
			print_error(basename(argv[i]));
		else
		{
			cat_fd(fd);
			close(fd);
		}
		i++;
	}
	return (0);
}
