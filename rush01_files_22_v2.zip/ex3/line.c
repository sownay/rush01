/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   line.c                                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: student <student@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/* ************************************************************************** */

#include <unistd.h>

void	puthex(unsigned char c);
void	put_offset(unsigned int off);

void	print_hex(unsigned char *b, int n)
{
	int	i;

	i = 0;
	while (i < 16)
	{
		if (i < n)
			puthex(b[i]);
		else
			write(1, "  ", 2);
		if (i == 7)
			write(1, "  ", 2);
		else
			write(1, " ", 1);
		i++;
	}
}

void	print_ascii(unsigned char *b, int n)
{
	int	i;

	write(1, " |", 2);
	i = 0;
	while (i < n)
	{
		if (b[i] >= 32 && b[i] <= 126)
			write(1, b + i, 1);
		else
			write(1, ".", 1);
		i++;
	}
	while (i++ < 16)
		write(1, " ", 1);
	write(1, "|\n", 2);
}
