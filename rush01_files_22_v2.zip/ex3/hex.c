/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   hex.c                                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: student <student@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/* ************************************************************************** */

#include <unistd.h>

void	puthex(unsigned char c)
{
	char	*hex;

	hex = "0123456789abcdef";
	write(1, &hex[c >> 4], 1);
	write(1, &hex[c & 15], 1);
}

void	put_offset(unsigned int off)
{
	char	*hex;
	int	i;

	hex = "0123456789abcdef";
	i = 7;
	while (i >= 0)
	{
		write(1, &hex[(off >> (i * 4)) & 15], 1);
		i--;
	}
}
