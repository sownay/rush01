/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: student <student@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/* ************************************************************************** */

#include <fcntl.h>
#include <unistd.h>
#include <libgen.h>

void	error(char *name);
void	hexdump(int fd);

int	main(int argc, char **argv)
{
	int	i;
	int	fd;

	if (argc < 3 || argv[1][0] != '-' || argv[1][1] != 'C')
		return (1);
	i = 2;
	while (i < argc)
	{
		fd = open(argv[i], O_RDONLY);
		if (fd < 0)
			error(basename(argv[i]));
		else
		{
			hexdump(fd);
			close(fd);
		}
		i++;
	}
	return (0);
}
