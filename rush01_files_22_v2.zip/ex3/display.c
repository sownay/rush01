/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   display.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: student <student@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/* ************************************************************************** */

#include <unistd.h>

void	put_offset(unsigned int off);
void	print_hex(unsigned char *b, int n);
void	print_ascii(unsigned char *b, int n);

void	print_line(unsigned char *b, int n, unsigned int off)
{
	put_offset(off);
	write(1, "  ", 2);
	print_hex(b, n);
	print_ascii(b, n);
}
