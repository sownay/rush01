/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   hexdump.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: student <student@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/* ************************************************************************** */

#include <unistd.h>

void	print_line(unsigned char *b, int n, unsigned int off);
void	put_offset(unsigned int off);

static int	is_same(unsigned char *a, unsigned char *b, int n)
{
	int	i;

	if (n != 16)
		return (0);
	i = 0;
	while (i < 16)
	{
		if (a[i] != b[i])
			return (0);
		i++;
	}
	return (1);
}

static void	copy_buf(unsigned char *dst, unsigned char *src, int n)
{
	int	i;

	i = 0;
	while (i < n)
	{
		dst[i] = src[i];
		i++;
	}
}

static void	process_block(unsigned char *buf, unsigned char *prev, int n,
	unsigned int off, int *star)
{
	if (is_same(buf, prev, n))
	{
		if (!*star)
			write(1, "*\n", 2);
		*star = 1;
	}
	else
	{
		print_line(buf, n, off);
		copy_buf(prev, buf, n);
		*star = 0;
	}
}

void	hexdump(int fd)
{
	unsigned char	buf[16];
	unsigned char	prev[16];
	unsigned int	off;
	int		n;
	int		star;

	off = 0;
	star = 0;
	while ((n = read(fd, buf, 16)) > 0)
	{
		process_block(buf, prev, n, off, &star);
		off += n;
	}
	put_offset(off);
	write(1, "\n", 1);
}
