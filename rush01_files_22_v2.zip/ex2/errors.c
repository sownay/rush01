/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   errors.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: student <student@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/* ************************************************************************** */

#include <unistd.h>
#include <errno.h>
#include <string.h>

void	error(char *name)
{
	char	*msg;
	int	i;

	msg = strerror(errno);
	write(2, "ft_tail: ", 9);
	i = 0;
	while (name[i])
		i++;
	write(2, name, i);
	write(2, ": ", 2);
	i = 0;
	while (msg[i])
		i++;
	write(2, msg, i);
	write(2, "\n", 1);
}
