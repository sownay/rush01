/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: student <student@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/* ************************************************************************** */

#include <unistd.h>
#include <fcntl.h>
#include <libgen.h>

void	error(char *name);
void	tail_fd(int fd, long long bytes);

long long	parse_bytes(char *s)
{
	long long	n;
	int		i;

	n = 0;
	i = 0;
	while (s[i] >= '0' && s[i] <= '9')
	{
		n = n * 10 + s[i] - '0';
		i++;
	}
	return (n);
}

void	process_file(char *name, long long n, int header, int first)
{
	int	fd;
	int	i;

	fd = open(name, O_RDONLY);
	if (fd < 0)
	{
		error(basename(name));
		return ;
	}
	if (header)
	{
		if (!first)
			write(1, "\n", 1);
		write(1, "==> ", 4);
		i = 0;
		while (name[i])
			i++;
		write(1, name, i);
		write(1, " <==\n", 5);
	}
	tail_fd(fd, n);
	close(fd);
}

int	main(int argc, char **argv)
{
	int	i;
	long long	n;

	if (argc < 3 || argv[1][0] != '-' || argv[1][1] != 'c')
		return (1);
	n = parse_bytes(argv[2]);
	i = 3;
	while (i < argc)
	{
		process_file(argv[i], n, argc > 4, i == 3);
		i++;
	}
	return (0);
}
