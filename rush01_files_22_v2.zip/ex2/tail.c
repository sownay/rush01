/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   tail.c                                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: student <student@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/* ************************************************************************** */

#include <unistd.h>
#include <stdlib.h>

static void	print_tail(char *buf, long long pos, long long bytes, long long total)
{
	if (total < bytes)
		write(1, buf, total);
	else
	{
		write(1, buf + pos, bytes - pos);
		write(1, buf, pos);
	}
}

void	tail_fd(int fd, long long bytes)
{
	char		*buf;
	long long	pos;
	long long	total;
	int		n;

	buf = malloc(bytes + 1);
	if (!buf)
		return ;
	pos = 0;
	total = 0;
	while ((n = read(fd, buf + pos, bytes - pos)) > 0)
	{
		pos += n;
		total += n;
		if (pos == bytes)
			pos = 0;
		if (total > bytes)
			total = bytes;
	}
	print_tail(buf, pos, bytes, total);
	free(buf);
}
