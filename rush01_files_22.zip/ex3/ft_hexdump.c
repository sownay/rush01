/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_hexdump.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: student <student@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/* ************************************************************************** */

#include <unistd.h>
#include <fcntl.h>
#include <string.h>
#include <errno.h>
#include <libgen.h>

void	puthex(unsigned char c)
{
	char	*hex;

	hex = "0123456789abcdef";
	write(1, &hex[c >> 4], 1);
	write(1, &hex[c & 15], 1);
}

void	print_line(unsigned char *b, int n, unsigned int off)
{
	char	*hex;
	int	i;

	hex = "0123456789abcdef";
	for (i = 7; i >= 0; i--)
		write(1, &hex[(off >> (i * 4)) & 15], 1);
	write(1, "  ", 2);
	for (i = 0; i < 16; i++)
	{
		if (i < n)
			puthex(b[i]);
		else
			write(1, "  ", 2);
		if (i == 7)
			write(1, "  ", 2);
		else
			write(1, " ", 1);
	}
	write(1, " |", 2);
	for (i = 0; i < n; i++)
	{
		if (b[i] >= 32 && b[i] <= 126)
			write(1, b + i, 1);
		else
			write(1, ".", 1);
	}
	for (; i < 16; i++)
		write(1, " ", 1);
	write(1, "|\n", 2);
}

void	hexdump(int fd)
{
	unsigned char	buf[16];
	unsigned char	prev[16];
	unsigned int	off;
	int		n;
	int		same;
	int		star;
	int		i;

	off = 0;
	star = 0;
	while ((n = read(fd, buf, 16)) > 0)
	{
		same = n == 16;
		if (same)
			for (i = 0; i < 16; i++)
				if (buf[i] != prev[i])
					same = 0;
		if (same)
		{
			if (!star)
				write(1, "*\n", 2);
			star = 1;
		}
		else
		{
			print_line(buf, n, off);
			for (i = 0; i < n; i++)
				prev[i] = buf[i];
			star = 0;
		}
		off += n;
	}
	for (i = 7; i >= 0; i--)
	{
		char *hex = "0123456789abcdef";
		write(1, &hex[(off >> (i * 4)) & 15], 1);
	}
	write(1, "\n", 1);
}

void	error(char *name)
{
	char	*msg;
	int	i;

	msg = strerror(errno);
	write(2, "ft_hexdump: ", 12);
	i = 0;
	while (name[i])
		i++;
	write(2, name, i);
	write(2, ": ", 2);
	i = 0;
	while (msg[i])
		i++;
	write(2, msg, i);
	write(2, "\n", 1);
}

int	main(int argc, char **argv)
{
	int	i;
	int	fd;

	if (argc < 3 || argv[1][0] != '-' || argv[1][1] != 'C')
		return (1);
	i = 2;
	while (i < argc)
	{
		fd = open(argv[i], O_RDONLY);
		if (fd < 0)
			error(basename(argv[i]));
		else
		{
			hexdump(fd);
			close(fd);
		}
		i++;
	}
	return (0);
}
