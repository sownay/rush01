/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_hexdump.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: student <student@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/09/22 21:00:00 by student           #+#    #+#             */
/*   Updated: 2026/09/22 21:00:00 by student          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>
#include <fcntl.h>
#include <string.h>
#include <errno.h>
#include <libgen.h>

int	ft_strlen(char *s)
{
	int	i;

	i = 0;
	while (s[i])
		i++;
	return (i);
}

void	puthex(unsigned char c)
{
	char	*hex;

	hex = "0123456789abcdef";
	write(1, &hex[c >> 4], 1);
	write(1, &hex[c & 15], 1);
}

void	offset(unsigned int n)
{
	char	*hex;
	int		i;

	hex = "0123456789abcdef";
	for (i = 7; i >= 0; i--)
		write(1, &hex[(n >> (i * 4)) & 15], 1);
	write(1, "  ", 2);
}

void	ascii(unsigned char *b, int n)
{
	int	i;

	write(1, " |", 2);
	for (i = 0; i < n; i++)
	{
		if (b[i] >= 32 && b[i] <= 126)
			write(1, b + i, 1);
		else
			write(1, ".", 1);
	}
	for (; i < 16; i++)
		write(1, " ", 1);
	write(1, "|\n", 2);
}

void	bytes(unsigned char *b, int n)
{
	int	i;

	for (i = 0; i < 16; i++)
	{
		if (i < n)
			puthex(b[i]);
		else
			write(1, "  ", 2);
		if (i == 7)
			write(1, "  ", 2);
		else
			write(1, " ", 1);
	}
	ascii(b, n);
}

int	same(unsigned char *a, unsigned char *b, int n)
{
	int	i;

	if (n != 16)
		return (0);
	for (i = 0; i < 16; i++)
		if (a[i] != b[i])
			return (0);
	return (1);
}

void	copy(unsigned char *dst, unsigned char *src, int n)
{
	int	i;

	for (i = 0; i < n; i++)
		dst[i] = src[i];
}

void	final_offset(unsigned int n)
{
	char	*hex;
	int	i;

	hex = "0123456789abcdef";
	for (i = 7; i >= 0; i--)
		write(1, &hex[(n >> (i * 4)) & 15], 1);
	write(1, "\n", 1);
}

void	show_block(unsigned char *buf, unsigned char *prev, int n,
	unsigned int off, int *star, int *have)
{
	if (*have && same(buf, prev, n))
	{
		if (!*star)
			write(1, "*\n", 2);
		*star = 1;
	}
	else
	{
		offset(off);
		bytes(buf, n);
		copy(prev, buf, n);
		*have = 1;
		*star = 0;
	}
}

void	hexdump(int fd)
{
	unsigned char	buf[16];
	unsigned char	prev[16];
	unsigned int	off;
	int				n;
	int				star;
	int				have;

	off = 0;
	star = 0;
	have = 0;
	while ((n = read(fd, buf, 16)) > 0)
	{
		show_block(buf, prev, n, off, &star, &have);
		off += n;
	}
	final_offset(off);
}

void	error(char *name)
{
	char	*msg;

	msg = strerror(errno);
	write(2, "ft_hexdump: ", 12);
	write(2, name, ft_strlen(name));
	write(2, ": ", 2);
	write(2, msg, ft_strlen(msg));
	write(2, "\n", 1);
}

int	main(int argc, char **argv)
{
	int	i;
	int	fd;

	if (argc < 3 || argv[1][0] != '-' || argv[1][1] != 'C')
		return (1);
	i = 2;
	while (i < argc)
	{
		fd = open(argv[i], O_RDONLY);
		if (fd < 0)
			error(basename(argv[i]));
		else
		{
			hexdump(fd);
			close(fd);
		}
		i++;
	}
	return (0);
}
