/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_tail.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: student <student@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/* ************************************************************************** */

#include <unistd.h>
#include <fcntl.h>
#include <stdlib.h>
#include <errno.h>
#include <string.h>
#include <libgen.h>

void	error(char *name)
{
	char	*msg;
	int		i;

	msg = strerror(errno);
	write(2, "ft_tail: ", 9);
	i = 0;
	while (name[i])
		i++;
	write(2, name, i);
	write(2, ": ", 2);
	i = 0;
	while (msg[i])
		i++;
	write(2, msg, i);
	write(2, "\n", 1);
}

void	tail_fd(int fd, long long bytes)
{
	char		*buf;
	long long	pos;
	long long	total;
	int		n;

	buf = malloc(bytes + 1);
	if (!buf)
		return ;
	pos = 0;
	total = 0;
	while ((n = read(fd, buf + pos, bytes - pos)) > 0)
	{
		pos += n;
		total += n;
		if (pos == bytes)
			pos = 0;
		if (total > bytes)
			total = bytes;
	}
	if (total < bytes)
		write(1, buf, total);
	else
	{
		write(1, buf + pos, bytes - pos);
		write(1, buf, pos);
	}
	free(buf);
}

int	main(int argc, char **argv)
{
	int		i;
	int		j;
	int		fd;
	long long	n;

	if (argc < 3 || argv[1][0] != '-' || argv[1][1] != 'c')
		return (1);
	n = 0;
	i = 0;
	while (argv[2][i] >= '0' && argv[2][i] <= '9')
		n = n * 10 + argv[2][i++] - '0';
	i = 3;
	while (i < argc)
	{
		fd = open(argv[i], O_RDONLY);
		if (fd < 0)
			error(basename(argv[i]));
		else
		{
			if (argc > 4)
			{
				if (i > 3)
					write(1, "\n", 1);
				write(1, "==> ", 4);
				j = 0;
				while (argv[i][j])
					j++;
				write(1, argv[i], j);
				write(1, " <==\n", 5);
			}
			tail_fd(fd, n);
			close(fd);
		}
		i++;
	}
	return (0);
}
