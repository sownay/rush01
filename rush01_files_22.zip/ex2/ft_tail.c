/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_tail.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: student <student@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/09/22 21:00:00 by student           #+#    #+#             */
/*   Updated: 2026/09/22 21:00:00 by student          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>
#include <fcntl.h>
#include <stdlib.h>
#include <errno.h>
#include <string.h>
#include <libgen.h>

int	ft_strlen(char *s)
{
	int	i;

	i = 0;
	while (s[i])
		i++;
	return (i);
}

void	error(char *name)
{
	char	*msg;

	msg = strerror(errno);
	write(2, "ft_tail: ", 9);
	write(2, name, ft_strlen(name));
	write(2, ": ", 2);
	write(2, msg, ft_strlen(msg));
	write(2, "\n", 1);
}

long long	number(char *s)
{
	long long	n;

	n = 0;
	while (*s >= '0' && *s <= '9')
		n = n * 10 + *s++ - '0';
	return (n);
}

void	write_tail(char *buf, long long pos, long long bytes, long long total)
{
	if (total < bytes)
		write(1, buf, total);
	else
	{
		write(1, buf + pos, bytes - pos);
		write(1, buf, pos);
	}
}

void	tail_fd(int fd, long long bytes)
{
	char		*buf;
	long long	pos;
	long long	total;
	int			n;

	buf = malloc(bytes + 1);
	if (!buf)
		return ;
	pos = 0;
	total = 0;
	while ((n = read(fd, buf + pos, bytes - pos)) > 0)
	{
		pos += n;
		total += n;
		if (pos == bytes)
			pos = 0;
		if (total > bytes)
			total = bytes;
	}
	write_tail(buf, pos, bytes, total);
	free(buf);
}

void	header(char *name, int first)
{
	if (!first)
		write(1, "\n", 1);
	write(1, "==> ", 4);
	write(1, name, ft_strlen(name));
	write(1, " <==\n", 5);
}

int	process_file(char *name, long long bytes, int show_header, int first)
{
	int	fd;

	fd = open(name, O_RDONLY);
	if (fd < 0)
	{
		error(basename(name));
		return (1);
	}
	if (show_header)
		header(name, first);
	tail_fd(fd, bytes);
	close(fd);
	return (0);
}

int	main(int argc, char **argv)
{
	int			i;
	long long	bytes;

	if (argc < 3 || argv[1][0] != '-' || argv[1][1] != 'c')
		return (1);
	bytes = number(argv[2]);
	i = 3;
	while (i < argc)
	{
		process_file(argv[i], bytes, argc > 4, i == 3);
		i++;
	}
	return (0);
}
