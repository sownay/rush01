/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_cat.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: student <student@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/09/22 21:00:00 by student           #+#    #+#             */
/*   Updated: 2026/09/22 21:00:00 by student          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>
#include <fcntl.h>
#include <errno.h>
#include <string.h>
#include <libgen.h>

int	ft_strlen(char *s)
{
	int	i;

	i = 0;
	while (s[i])
		i++;
	return (i);
}

void	print_error(char *file)
{
	char	*msg;

	msg = strerror(errno);
	write(2, "ft_cat: ", 8);
	write(2, file, ft_strlen(file));
	write(2, ": ", 2);
	write(2, msg, ft_strlen(msg));
	write(2, "\n", 1);
}

void	cat_fd(int fd)
{
	char	buf[30000];
	int		n;

	while ((n = read(fd, buf, sizeof(buf))) > 0)
		write(1, buf, n);
}

int	main(int argc, char **argv)
{
	int	i;
	int	fd;

	if (argc == 1)
		cat_fd(0);
	i = 1;
	while (i < argc)
	{
		fd = open(argv[i], O_RDONLY);
		if (fd < 0)
			print_error(basename(argv[i]));
		else
		{
			cat_fd(fd);
			close(fd);
		}
		i++;
	}
	return (0);
}
