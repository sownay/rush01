/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_display_file.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: student <student@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/09/22 21:00:00 by student           #+#    #+#             */
/*   Updated: 2026/09/22 21:00:00 by student          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>
#include <fcntl.h>

void	put_error(char *s)
{
	while (*s)
		write(2, s++, 1);
	write(2, "\n", 1);
}

int	main(int argc, char **argv)
{
	int		fd;
	int		n;
	char	buf[4096];

	if (argc < 2)
		return (put_error("File name missing."), 1);
	if (argc > 2)
		return (put_error("Too many arguments."), 1);
	fd = open(argv[1], O_RDONLY);
	if (fd < 0)
		return (put_error("Cannot read file."), 1);
	while ((n = read(fd, buf, sizeof(buf))) > 0)
		write(1, buf, n);
	close(fd);
	return (0);
}
